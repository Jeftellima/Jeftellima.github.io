Pequeno sistema de login e senha feito em python, com uma interface gráfica de usuário (Tkinter).
Foi criado um banco de dados e integrado ao sistema. Um projeto simples e com bastante comentários
para facilitar o entendimento do código.
